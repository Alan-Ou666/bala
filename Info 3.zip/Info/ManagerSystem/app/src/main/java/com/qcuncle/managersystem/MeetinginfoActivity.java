package com.qcuncle.managersystem;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import data.dbHelper;

public class MeetinginfoActivity extends Activity {
    private static String DB_NAME = "mydb";
    private EditText et_no;
    private EditText et_name;
    private EditText et_ar;
    private EditText et_pr;
    private ArrayList<Map<String, Object>> data;
    private data.dbHelper dbHelper;
    private SQLiteDatabase db;
    private Cursor cursor;
    private SimpleAdapter listAdapter;
    private View view;
    private ListView listview;
    private Button selBtn, addBtn, updBtn, delBtn;
    private Map<String, Object> item;
    private String selId;
    private ContentValues selCV;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_informatin);
        listview = (ListView) findViewById(R.id.list_book);
        et_no = (EditText) findViewById(R.id.et_no);
        et_name = (EditText) findViewById(R.id.et_name);
        et_ar = (EditText) findViewById(R.id.et_ar);
        et_pr = (EditText) findViewById(R.id.et_pr);

        addBtn = (Button) findViewById(R.id.addBtn);
        updBtn = (Button) findViewById(R.id.updateBtn);
        delBtn = (Button) findViewById(R.id.deleteBtn);
        init();

        dbHelper = new dbHelper(this, DB_NAME, null, 1);
        db = dbHelper.getWritableDatabase();// DB
        data = new ArrayList<Map<String, Object>>();
        dbFindAll();

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                // TODO Auto-generated method stub
                Map<String, Object> listItem = (Map<String, Object>) listview.getItemAtPosition(position);
                et_no.setText((String) listItem.get("bno"));
                et_name.setText((String) listItem.get("bname"));
                et_ar.setText((String) listItem.get("bar"));
                et_pr.setText((String) listItem.get("bpr"));
                selId = (String) listItem.get("_id");
                Log.i("mydbDemo", "_id=" + selId);
            }
        });
    }
    private void init() {

        addBtn.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                dbAdd();
                dbFindAll();
            }
        });
        updBtn.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                dbUpdate();
                dbFindAll();
            }
        });
        delBtn.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                dbDel();
                dbFindAll();
            }
        });
    }

    //delete
    protected void dbDel() {
        // TODO Auto-generated method stub
        String where = "_id=" + selId;
        int i = db.delete(dbHelper.TB_NAME, where, null);
        if (i > 0)
            Log.i("myDbDemo", "Data deleted successfully!");
        else
            Log.e("myDbDemo", "Data not deleted!");
    }
    private void showList() {
        // TODO Auto-generated method stub
        listAdapter = new SimpleAdapter(this, data,
                R.layout.list_item, new String[]{"bno","bname","bar", "bpr"}, new int[]{R.id.tvNo, R.id.tvName, R.id.tvAr,R.id.tvPr,});
        listview.setAdapter(listAdapter);
    }
    //update
    protected void dbUpdate() {
        // TODO Auto-generated method stub
        ContentValues values = new ContentValues();
        values.put("bno", et_no.getText().toString().trim());
        values.put("bname", et_name.getText().toString().trim());
        values.put("bar", et_ar.getText().toString().trim());
        values.put("bpr", et_pr.getText().toString().trim());
        String where = "_id=" + selId;
        int i = db.update(dbHelper.TB_NAME, values, where, null);
        if (i > 0)
            Log.i("myDbDemo", "Data updated successfully！");
        else
            Log.e("myDbDemo", "Data not updated");
    }
    //add
    protected void dbAdd() {
        // TODO Auto-generated method stub
        ContentValues values = new ContentValues();
        values.put("bno", et_no.getText().toString().trim());
        values.put("bname", et_name.getText().toString().trim());
        values.put("bar", et_ar.getText().toString().trim());
        values.put("bpr", et_pr.getText().toString().trim());
        long rowid = db.insert(dbHelper.TB_NAME, null, values);
        if (rowid == -1)
            Log.e("myDbDemo", "Failed to add data！");
        else
            Log.i("myDbDemo", "Data added successfully!" + rowid);
    }

    //search
    protected void dbFindAll() {
        // TODO Auto-generated method stub
        data.clear();
        cursor = db.query(dbHelper.TB_NAME, null, null, null, null, null, "_id ASC");
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            String id = cursor.getString(0);
            String bno = cursor.getString(1);
            String bname = cursor.getString(2);
            String bar = cursor.getString(3);
            String bpr = cursor.getString(4);
            item = new HashMap<String, Object>();
            item.put("_id", id);
            item.put("bno", bno);
            item.put("bname", bname);
            item.put("bar", bar);
            item.put("bpr", bpr);
            data.add(item);
            cursor.moveToNext();
        }
        cursor.close();
        showList();
    }
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.setClass(MeetinginfoActivity.this,MainActivity.class);
        startActivity(intent);

        MeetinginfoActivity.this.finish();
    }
}
